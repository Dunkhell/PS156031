#include <stdio.h>
#include <stdlib.h>
int absolute (int a)
{
    int b;
    if (a<0)
        return -b;
    return b;
}

int main()
{
    int a;
    scanf("%i",&a);
    printf("Wartosc bezwzgledna liczby %i to %i",a, absolute(a));
    return 0;
}
