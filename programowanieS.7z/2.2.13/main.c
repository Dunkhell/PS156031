#include <stdio.h>
#include <stdlib.h>
int pierw (unsigned int x)
{
    int pocz= 0, kon= x, sr;
    while (kon - pocz > 1)
    {
        sr=(pocz+ kon) /2;
        if (sr * sr <= x)
            pocz=sr;
        else
            kon=sr;
    }
    if (x<=1)
        return kon;
    else
        return pocz;
}
void write (unsigned int n)
{
    int p;
    for (int i=1; i <= pierw(n); i+=1)
       {

        p=pierw(n-i*i);
        if ((p!=0)&&(i*i+p*p==n))
            printf("%d*%d+%d*%d=%d\n",i,i,p,p,n);
        }

}
int main()
{
    int n;
    scanf("%i",&n);
    write(n);
}
