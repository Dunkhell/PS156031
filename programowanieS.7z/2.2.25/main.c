#include <stdio.h>
#include <stdlib.h>
int ciag(int n)
{
    if (n==0 || n==1)
        return 0;
    if (n%2==0)
        return ciag(n-1)+n;
    return ciag(n-1)*n;
}
int main()
{
    int n;
    scanf("%i",&n);
    printf("%i wyrazem tego ciagu jest %i",n,ciag(n));
}
