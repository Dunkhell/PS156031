#include <stdio.h>
#include <stdlib.h>
int fun(int n,int m)
{
    if (m==0)
        return n;
    return n-m+fun(n-1,m)+fun(n,m-1);
}
int main()
{
    printf("Wartosc to %i",fun(1,1));
    return 0;

}
