#include <stdio.h>
#include <stdlib.h>
int potega(int n)
{
    int wynik=1;
    for (int i=0;i<n;i+=1)
    {
        wynik=wynik*2;
    }
    return wynik;
}
int main()
{
    int n;
    scanf("%i",&n);
    printf("Wynik to %i",potega(n));
    return 0;
}
