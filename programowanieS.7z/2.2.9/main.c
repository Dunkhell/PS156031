#include <stdio.h>
#include <stdlib.h>
float pierw (float n, int m)
{
    float wynik=n;
        for (int i=1; i<m; i=i+1)
        {
                ;
        }
        return wynik;
}
int main()
{
    float n;
    int m;
    do
    {
        scanf("%f",&n);
    }while (n<0);
    do
    {
        scanf("%i",&m);
    }while (m<1);
    printf("Pierwiastek z liczby %f stopnia %i wynosi %f",n,m, pierw(n,m));

    return 0;
}
